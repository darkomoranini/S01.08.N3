import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class App {

	public static void main(String[] args) {

		ArrayList<Alumno>listaAlumnos=new ArrayList<Alumno>();
		listaAlumnos.add(new Alumno("Ana", 20, "JAVA", 7.5));
		listaAlumnos.add(new Alumno("Alberto", 29, "PHP", 4.2));
		listaAlumnos.add(new Alumno("Alex", 31, "JAVA", 6.8));
		listaAlumnos.add(new Alumno("Emma", 18, "Python", 8.9));
		listaAlumnos.add(new Alumno("David", 20, "JAVA", 5.2));
		listaAlumnos.add(new Alumno("Laura", 22, "PHP", 6.7));
		listaAlumnos.add(new Alumno("Alicia", 19, "JAVA", 9.1));
		listaAlumnos.add(new Alumno("Eric", 20, "Python", 7.2));
		listaAlumnos.add(new Alumno("Pau", 28, "PHP", 3.8));
		listaAlumnos.add(new Alumno("Maria", 27, "JAVA", 5.9));

		// Mostrar nombre y edad
		listaAlumnos.forEach(alumno -> System.out.println(alumno.getNombre() + " - " + alumno.getEdad()));

		// alumnos con nombre que empiece por 'A'
		List<Alumno> alumnosConA = listaAlumnos.stream()
				.filter(alumno -> alumno.getNombre().toLowerCase().startsWith("a"))
				.collect(Collectors.toList());

		System.out.println("\nAlumnos que empiezan por 'A':");
		alumnosConA.forEach(alumno -> System.out.println(alumno.getNombre() + " - " + alumno.getEdad()));

		// alumnos aprobados 
		List<Alumno> alumnosAprobados = listaAlumnos.stream()
				.filter(alumno -> alumno.getNota() >= 5)
				.collect(Collectors.toList());

		System.out.println("\nAlumnos aprobados:");
		alumnosAprobados.forEach(alumno -> System.out.println(alumno.getNombre() + " - " + alumno.getEdad()+" - "+ alumno.getNota()));

		// alumnos aprobados de PHP
        List<Alumno> alumnosAprobadosPHP = listaAlumnos.stream()
                .filter(alumno -> alumno.getNota() >= 5 && !alumno.getCurso().equalsIgnoreCase("PHP"))
                .collect(Collectors.toList());

        System.out.println("\nAlumnos aprobados de PHP:");
        alumnosAprobadosPHP.forEach(alumno -> System.out.println(alumno.getNombre() + " - " + alumno.getEdad()+" - "+ alumno.getNota()));
        
        System.out.println("\nAlumnos de JAVA mayores de edad:");
        listaAlumnos.stream()
                .filter(alumno -> alumno.getCurso().equalsIgnoreCase("JAVA") && alumno.getEdad() >= 18)
                .forEach(alumno -> System.out.println(alumno.getNombre() + " - " + alumno.getEdad()+" - "+ alumno.getNota()));

	}
}
